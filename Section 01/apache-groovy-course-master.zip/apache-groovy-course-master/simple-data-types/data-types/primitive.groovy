// using the def keyword
def x = 1
println x
println x.class

// what looks like a primitive is not a primitive
int y = 2
println y
println y.class


// Remmber I mentioned Strings? Why aren't strings and arrays
// mentioned in that table? Its because they are reference types
// not primitives
