Person p = new Person("Dan","Vega")
println p