class Developer {

    String firstName
    String lastName
    int age
    def languages = []
    
    void writeCode(){
        println "writing code..."
    }

}