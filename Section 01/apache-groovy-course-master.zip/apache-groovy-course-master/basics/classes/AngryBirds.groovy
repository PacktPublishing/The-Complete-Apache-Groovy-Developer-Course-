class AngryBirds {

}

class Bird { }
class Pig { }