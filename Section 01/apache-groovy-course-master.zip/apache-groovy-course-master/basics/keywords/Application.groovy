/**
 * My Applicaiton Class
 */
class class {

    private final String NAME = "THE_REAL_DAN_VEGA"

    String def = "some message"

}