package com.therealdanvega

Person p = new Person(first:"Dan",last: "Vega",email:"danvega@gmail.com",dob: new Date() )

println p.toString()

