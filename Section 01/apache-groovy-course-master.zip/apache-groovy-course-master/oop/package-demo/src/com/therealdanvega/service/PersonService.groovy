package com.therealdanvega.service

import com.therealdanvega.domain.Person

class PersonService {

    Person person

}
