package com.therealdanvega.traits

class Bird implements FlyingAbility, SpeakingAbility {

    @Override
    String foo() {
        return null
    }
}
