package com.therealdanvega

//Employee emp = new Employee(first:"Dan",last: "Vega",email: "danvega@gmail.com")
//println emp

//Employee emp = new Employee()
//emp.first = "Dan"

// println emp.first

DoubleBean db = new DoubleBean()
db.value = 100

println db.value
println db.@value