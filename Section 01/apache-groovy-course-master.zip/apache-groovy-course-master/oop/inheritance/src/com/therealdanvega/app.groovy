package com.therealdanvega

import com.therealdanvega.domain.IPhone

IPhone phone = new IPhone(name:"iPhone",appStore: "Apple Store", os: "ios")
println phone