package com.therealdanvega.domain

class Phone {

    String name
    String os
    String appStore

    def powerOn(){

    }

    def powerOff(){

    }

    def ring(){

    }

}
