package canonical

import groovy.transform.Canonical

@Canonical
class Person {

    String first
    String last
    String email

}
