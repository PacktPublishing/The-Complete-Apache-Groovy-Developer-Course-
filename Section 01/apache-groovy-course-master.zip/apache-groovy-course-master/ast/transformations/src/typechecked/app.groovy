package typechecked

Person p = new Person("Dan","Vega")
println p.toString()