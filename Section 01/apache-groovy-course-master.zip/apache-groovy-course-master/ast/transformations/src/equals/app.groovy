package equals

Person p1 = new Person(first:"Dan",last: "Vega",email: "danvega@gmail.com")
Person p2 = new Person(first:"Dan",last: "Vega",email: "dvega@work.com")

assert p1 == p2