
Developer developer = new Developer(first: "Dan",last: "Vega",email: "danvega@gmail.com")
developer.writeCode("Groovy")
println developer.first
developer.languages = ["Groovy","Java"]