for( int x = 1; x <= 10; ++x) { 
    print x
}

println ""

for( int y = 10; y >= 1; --y) {
    print y
}

println ""

def letters = ['a','b','c']
for( int i = 0; i < letters.size(); ++i) {
    print letters[i]
}