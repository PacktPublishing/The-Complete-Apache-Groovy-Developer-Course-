package generator

class DocUtils {
    @Lazy public static final String DOCS_BASEURL = System.getProperty('docs_baseurl')
}
